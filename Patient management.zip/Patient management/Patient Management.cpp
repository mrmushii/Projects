#include <iostream>
#include <fstream>
#include <windows.h>
#include <sstream>
#include <conio.h>

using namespace std;
void menu1();
void menu();
class Login{
private:
string LoginID,Password;
public:
Login():LoginID(""),Password(""){}

void setID(string id){
LoginID = id;
}

void setPW(string pw){
Password = pw;
}

string getID(){
return LoginID;
}

string getPW(){
return Password;
}
};
registration(Login log){
system("cls");
system("color 70");
string id,pw;
cout<<"\n\n\t\tEnter Login Id: ";
cin>>id;
log.setID(id);

start:
cout<<"\t\tEnter Password: ";
cin>>pw;
if(pw.length()>=8){

log.setPW(pw);
}
else{
cout<<"\t\tEnter Minimum 8 Characters!"<<endl;
goto start;
}
ofstream outfile("D:\Study Material\login.txt",ios::app);
if(!outfile){
cout<<"\tError"<<endl;
}
else{
outfile<<"\t"<<log.getID()<<" : "<<log.getPW()<<endl<<endl;
cout<<"\tUser Registered Successfully!"<<endl;
}
outfile.close();
Sleep(3000);


}

login(){
system("cls");
system("color 70");
string id,pw;
m:
cout<<"\n\n\t\tEnter Login Id: ";
cin>>id;

cout<<"\t\tEnter Password: ";
cin>>pw;

ifstream infile("D:\Study Material\login.txt");
if(!infile){
cout<<"\tError!"<<endl;
}
else{
string line;
bool found = false;
while(getline(infile,line)){
stringstream ss;
ss<<line;
string userID,userPW;
char delimiter;
ss>>userID>>delimiter>>userPW;

if(id==userID && pw==userPW){
found = true;
cout<<"\t\tPlease Wait";
for(int i=0;i<3;i++){
    cout<<".";
    Sleep(800);
}
system("cls");
menu1();
}
}
if(!found){
cout<<"\t\tError: Incorrect Login ID or Password!"<<endl;
goto m;
}
}
infile.close();


}


class patient{
private:
string Name,Sex,Address,PMH;
int Id,Age,Mobile;
public:
patient():Name(""),Age(0),Sex(""),Mobile(0),Address(""),PMH(""),Id(0){}

void setName(string name){
    Name = name;
}
void setSex(string sex){
    Sex = sex;
}
void setAddress(string address){
    Address = address;
}
void setPMH(string pmh){
    PMH = pmh;
}
void setId(int id){
    Id = id;
}
void setAge(int age){
    Age = age;
}
void setMobile(int mobile){
    Mobile = mobile;
}
string getName(){
    return Name;
}
string getSex(){
    return Sex;
}
string getAddress(){
    return Address;
}
string getPMH(){
    return PMH;
}
int getId(){
    return Id;
}
int getAge(){
    return Age;
}
int getMobile(){
    return Mobile;
}
};


void addPatient(patient p){
string name,sex,address,pmh;
system("color 70");

int id,age,mobile;

cout<<"\n\n\t\tEnter Patient's Id : ";
cin>>id;
p.setId(id);

cout<<"\t\tEnter Patient Name : ";
cin.ignore();
getline(cin, name);
p.setName(name);

cout<<"\t\tEnter Patient's Age : ";
cin>>age;
p.setAge(age);

cout<<"\t\tEnter Patient's Sex : ";
cin>>sex;
p.setSex(sex);

cout<<"\t\tEnter Patient's Mobile No : ";
cin>>mobile;
p.setMobile(mobile);

cout<<"\t\tEnter Patient's Address : ";
cin.ignore();
getline(cin, address);
p.setAddress(address);

cout<<"\t\tPast Medical History "<<"(If none write NAD) : ";
cin.ignore();
getline(cin, pmh);
p.setPMH(pmh);

ofstream file;
file.open("D:\Study Material\Hospital Management.txt",ios::app);
if(!file){
    cout<<"\n\n\t\tERROR: File Not Available!"<<endl;

}
else{
    file<<"ID : "<<p.getId()<<"\tName : "<<p.getName()<<"\tAge : "<<p.getAge()<<"\tSex : "<<p.getSex()<<"\tMobile : "<<p.getMobile()<<"\tAddress : "<<p.getAddress()<<"\tPre Medical History : "<<p.getPMH()<<endl;

    cout<<"\t\tPatient Successfully Registered!"<<endl;
}
file.close();
}

void searchP(patient p){
string id;
cout<<"\n\n\t\tEnter Patient Id : ";
cin>>id;

ifstream file("D:\Study Material\Hospital Management.txt");
if(!file){
    cout<<"\t\tError : File cannot open!"<<endl;


}
else{
string Id;
bool found = false;
while (getline(file,Id)) {
int pos = Id.find(id);
if(pos != string::npos) {
    found = true;
    cout <<Id<<endl;
}
}
if(!found){
    cout<<"\t\tNo Patient Found!"<<endl;
}
}
}

void cover() //Name of Project
{
	system("color 07"); // you can also change the color by adding b6 instead of 07
	char x=175;
	char y=174;
	char z=240;
	cout<<endl<<endl<<endl<<endl;
	for(int n=0;n<122;n++)
	{
		cout<<z;
	}
	for(int n=0;n<61;n++)
	{
	cout<<" "<<x;
	cout<<" "<<y;
	}
	cout<<endl;
	cout<<"\t\t\t\t\t\t________________\n\n";
	cout<<"\t\t\t\t\t\tMedicine Lbrary";
	cout<<"\n\t\t\t\t\t\t______________";
	cout<<endl<<endl;
	for(int n=0;n<61;n++)
	{
	cout<<" "<<x;
	cout<<" "<<y;
	}
		for(int n=0;n<122;n++)
	{
		cout<<z;
	}
		cout<<endl;
	cout<<"\n\n\n\n\n\n\n\t\t\tCopyrights 2024, Mushfiq's Medicine Library , All Rights Reserved.";
	for(int n=0;n<28;n++)
	{
		cout<<".";
		Sleep(100);
	}
}
//making history function start
void history()
{
	system("cls");
    cout<<"\n\n\n\n\n\n\n\n\n__________________________________________________________________________________________________________________________";
	cout<<"\n\n\n\n\t\t\t\t\t\t\tHistory\n";
	cout<<"\t\t\t\t\t\t\t_______\n\n";
	 char hist[10];
	 int X=1;
	ifstream file("history.txt",ios::out);
	cout<<"\t\t\t\t\t\tHistory of last searches is:";
	while(!file.eof())
	{
	file>>hist;
	cout<<"\n\t\t\t\t\t\t"<<X++<<"-"<<" "<<hist;
	}
	file.close();
	     cout<<"\n\n__________________________________________________________________________________________________________________________";
		 cout<<"\t\t\t\tCopyrights 2024, Mushfiq's Medicine Library, All Rights Reserved\t  Press ENTER to continue";
		 getch();
}//making history function end

//loading function start
void load()
{
	cout<<endl<<endl<<endl;
	cout<<"\n\n\n\n\n\n\n\t\t\t\t\t\t______________________\n\n";
	cout<<"\t\t\t\t\t\tMushfiq's Medicine Library";
	cout<<"\n\t\t\t\t\t\t______________________";
	cout<<endl<<endl;
	system("color 70");
 cout<<"\n\t\t\t\t\t\t LOADING Please Wait\n";
 cout<<"\t\t\t\t\t\t ___________________\n\n\n";
	 for (int i=0;i<=99;i++)
 {
 cout<<"\t\t\t\t\t\t\t "<<i<<"%\r";
 Sleep(20);
 }
system("cls");
}//loading function end

//searching function start
void search()
{
	cout<<"\t\tSEARCHING";
	for(int n=0;n<15;n++)
	{
		cout<<".";
		Sleep(100);
	}
	system("cls");
}//loading function end
void loading()
{
	cout<<"\t\tLOADING";
	for(int n=0;n<10;n++)
	{
		cout<<".";
		Sleep(100);
	}
	system("cls");
}//exiting function end
void exiting()
{
	cout<<"\t\tEXITING";
	for(int n=0;n<13;n++)
	{
		cout<<".";
		Sleep(150);
	}
	system("cls");
}//exiting function end
void menu1(){
patient p;
menu:
system("color F4");
system("cls");
cout<< "\n\t\t\t\t\t\tPatient Management Window"<<endl;
cout<< "\t\t\t\t\t\t*************************"<<endl;
cout<< "\n\t\t\t\t\t\t1.Add Patient."<<endl;
cout<< "\t\t\t\t\t\t2.Search Patient."<<endl;

cout<< "\t\t\t\t\t\t3.Medicine Library."<<endl;
cout<< "\t\t\t\t\t\t4.Logout"<<endl;
cout<< "\t\t\t\t\t\tEnter Choice : ";
bool exit = false;
while(!exit){



int val;
cin>>val;

if(val==1){
 system("cls");
 addPatient(p);
 Sleep(3000);
goto menu;
}

else if(val==2){
system("cls");
searchP(p);
Sleep(5000);
goto menu;
}
else if(val==3){
system("cls");
load();
cover();
menu();

}
else if(val==4){
 system("cls");
 exit = true;
 cout<<"\n\t\t\t\t\t\tEat Healthy And Be Healthy ";
 for(int i=0;i<3;i++){
    cout<<".";
    Sleep(700);

 }

}
}
}
void menu(){
ofstream file("history.txt",ios::trunc);
	//checking condition wether to see history or Search
	menue:
		int X;

		system("cls");
		system("color 70");
		cout<<"\n\n\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t\t\tMAIN MENU";
		cout<<"\n\t\t\t\t\t\t\t_________\n";
		cout<<"\n\n\t\t1.SEARCH  "<<"\n\t\t2.HISTORY "<<"\n\t\t3.EXIT : "<<"\n\t\tEnter your choice:";
		cin>>X;

		if(X==2)//calling history function
		{
		file.close(); //Input file closed there
			cout<<"\n\n\n\n\n\t\t\t";loading();

		history();
		goto menue;
		}



		else if(X==1)
		{

	char word[30];
	char *word2[6][2]={

				//****************************AAAAAAA
{"paracetamol","Tab. Napa 500mg,Tab. Ace 500mg"},
{"rolac","Tab. Rolac 10mg,Tab. Torax 10mg"},
{"azith","Tab. Zimax 500mg,Tab. Zimax 250mg"},
{"cefuro","Tab. Cefotil 500mg,Tab. Cefotil 250mg"},
{"metro","Tab. Filmet 400mg,Tab. Filmet 200mg"},
{"esomeprazole","Cap. Maxpro 20mg,Cap. Esonix 20mg"},
};

	//declaring variables
	int length,main,m=0;
	system("cls");
	cout<<"\n\n\n\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t\t\tDICTIONARY";
	cout<<"\n\t\t\t\t\t\t\t__________\n\n";
	cout<<"\n\t\t\t\t\t  For correct result enter the word in lowercase";
	cout<<"\n\t\t\t\t\t  Enter a word to search : ";
	//taking word input
	cin>>word;
	 //file input
	file<<word<<'\n';

    cout<<"\n\n\n\n\n\t\t\t\t";search();
//logic
length=strlen(word)-1;
for(main=0;main<6;main++)
    {
      for(int n=0;n<1;n++)
	    {
          for(int k=0;k<=length;k++)
		   {
	         if(word2[main][n][k]==(NULL))
			 {
	         k=length;
	         }
	    else if(word[k]==word2[main][n][k])
		{
	    m++;
	    }
	  else
	  {
	    m=0;
	  }
	  if(m==length+1)
	  {
	     cout<<"\n\n\n\n\n\n\n\n\n\n\n__________________________________________________________________________________________________________________________";
	     cout<<"\n\n\n\t\t\t\t\t\t\tRESULT";
	cout<<"\n\t\t\t\t\t\t\t______\n\n\n\n\n";
		 cout<<"\t\t\t\t  "<<word<<":"<<word2[main][n+1]<<"\n";
	     cout<<"\n\n__________________________________________________________________________________________________________________________";
		 cout<<"\t\t\t\tCopyrights 2024, Mushfiq's Medicine Library, All Rights Reserved\t  Press ENTER to continue";
		 getch();
	     k=length;main=4803;
	     goto menue;
	  }//output
      }//length
   	}//columns
   }//main loop barceket(rows)
	if(main==6 && m==0)
	{
	     cout<<"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n__________________________________________________________________________________________________________________________";
    cout<<"\n\n\n\n\t\t\t\t\t\t  Oops! No Results found.\n";
    cout<<"\n\n__________________________________________________________________________________________________________________________";
		cout<<"\t\t\t\tCopyrights 2024, Mushfiq's Medicine Library, All Rights Reserved\t  Press ENTER to continue";
    getch();
	}

    goto menue;

	}//if else bracket
else
{
	file.close();

	cout<<"\n\n\n\n\t\t\t\t";exiting();
    menu1();

}

}

int main(){
Login log;
patient p;

bool exit = false;
while(!exit){
system("cls");
system("color F4");
int n;
m1:
cout<<"\n\n\t\t\t\t\tWelcome To REgistration & Login Form"<<endl;
cout<<"\t\t\t\t\t************************************"<<endl;
cout<<"\t\t\t\t\t1.Register."<<endl;
cout<<"\t\t\t\t\t2.Login."<<endl;
cout<<"\t\t\t\t\t3.Exit"<<endl;
cout<<"\t\t\t\t\tEnter Choice: ";
cin>>n;

if(n==1){
registration(log );
}
else if(n==2){
login();

}

else if(n==3){
system("cls");
exit = true;
cout<<"\tThank You"<<endl;
}
Sleep(3000);
}

}
